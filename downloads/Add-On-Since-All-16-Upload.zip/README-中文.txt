英文文章素材 · 增量包

本包只包含 5 篇新增文章，供已经上传过前一批的情况使用。

包含的新增文章：
  • How to Organize a Holiday Potluck（Holidays and Traditions）：15 步，16 张插画
  • How to Plan a School Club Meeting（Youth）：15 步，16 张插画
  • How to Map a Philosophical Argument（Philosophy and Religion）：15 步，16 张插画
  • How to Make a Sincere Apology（Relationships）：15 步，16 张插画
  • How to Listen More Actively（Relationships）：15 步，16 张插画

每篇一个文件夹，里面是：
• index.html：英文图文网页（每步一图，另有封面）
• Article-English.txt：纯文本英文稿，首行标明仍需真人审校
• README-中文.txt：该篇的单独说明，含所属类目与审校提示
• Images/：每张图两档，-1600.webp 与 -960.webp，网页按屏幕宽度自动选择

关于根目录的 index.html：
它是本地总目录页，列出了全部 21 篇（新增 5 篇 + 之前已上传的 16 篇）。
把它覆盖到和各篇文件夹同级的位置，目录页就能一次列全。
下面这些篇目的卡片指向服务器上已有的文件夹，本包内没有重复携带：
  - Run-Your-First-5K/
  - Repot-a-Houseplant/
  - Plan-a-Run-Walk-Workout/
  - Back-Up-Your-Photos/
  - Check-Your-Tire-Pressure/
  - Meal-Prep-Safely-for-the-Week/
  - Build-an-Emergency-Fund/
  - Organize-Medicines-Safely-at-Home/
  - Pack-a-Personal-Item-for-a-Trip/
  - Hold-a-Family-Meeting/
  - Build-a-Dog-Walking-Routine/
  - Begin-a-Watercolor-Sketchbook/
  - Prepare-for-a-One-on-One-Meeting/
  - Care-for-Dry-Hands/
  - Make-Effective-Study-Flashcards/
  - Hang-a-Picture-Securely/

上传提示：
解压后把各篇文件夹整体放进服务器的静态目录，保持文件夹内 index.html 与 Images 同级。
这是独立静态网页素材，不是经过验证的 CMS 导入包，不会自动进入网站原有的文章数据库和分类。

审校提示：
所有稿件均未经真人专业审校，正文与网页上都带有提示。
医疗、用药、财务、食品安全、汽车、宠物健康、皮肤健康等内容务必先由对口专业人士核校。
不要虚填作者或专家信息。各篇具体需要核查的内容见该篇的 README-中文.txt。
