英文文章素材包合集（共 14 篇）

包内每个文件夹是一篇独立文章，内容与单篇素材包完全一致：
• index.html：英文图文网页（每步一图，另有封面）
• Images：每张插画两档 WebP（1600×900 与 960×540），网页按屏幕宽度自动选用
• Article-English.txt：英文正文与链接，适合人工复制
• README-中文.txt：该篇的单独说明，含所属类目与审校提示

篇目：
• Run-Your-First-5K/　How to Run Your First 5K
　　类目 Sports and Fitness｜15 个步骤｜16 张图
• Repot-a-Houseplant/　How to Repot a Houseplant
　　类目 Home and Garden｜15 个步骤｜16 张图
• Plan-a-Run-Walk-Workout/　How to Plan a Run-Walk Workout
　　类目 Sports and Fitness｜15 个步骤｜16 张图
• Back-Up-Your-Photos/　How to Back Up Your Photos
　　类目 Computers and Electronics｜15 个步骤｜16 张图
• Check-Your-Tire-Pressure/　How to Check Your Tire Pressure
　　类目 Cars and Other Vehicles｜15 个步骤｜16 张图
• Meal-Prep-Safely-for-the-Week/　How to Meal Prep Safely for the Week
　　类目 Food and Entertaining｜15 个步骤｜16 张图
• Build-an-Emergency-Fund/　How to Build an Emergency Fund
　　类目 Finance and Business｜15 个步骤｜16 张图
• Organize-Medicines-Safely-at-Home/　How to Organize Medicines Safely at Home
　　类目 Health｜15 个步骤｜16 张图
• Pack-a-Personal-Item-for-a-Trip/　How to Pack a Personal Item for a Trip
　　类目 Travel｜15 个步骤｜16 张图
• Hold-a-Family-Meeting/　How to Hold a Family Meeting
　　类目 Family Life｜15 个步骤｜16 张图
• Build-a-Dog-Walking-Routine/　How to Build a Dog Walking Routine
　　类目 Pets and Animals｜15 个步骤｜16 张图
• Begin-a-Watercolor-Sketchbook/　How to Begin a Watercolor Sketchbook
　　类目 Hobbies and Crafts｜15 个步骤｜16 张图
• Prepare-for-a-One-on-One-Meeting/　How to Prepare for a One-on-One Meeting
　　类目 Work World｜15 个步骤｜16 张图
• Care-for-Dry-Hands/　How to Care for Dry Hands
　　类目 Personal Care and Style｜15 个步骤｜16 张图

本目录下的 index.html 是一个总目录页，双击即可在浏览器里逐篇预览，
它只为本地查看方便，不必上传服务器。

使用方式：解压后，把需要的文章文件夹整个放到服务器上可被网站访问的静态目录，
保持该文件夹内 index.html 与 Images 同级。能否通过网址访问取决于服务器配置。

重要：本包不是已验证的文章系统导入包。上传压缩包本身不会发布文章，
也不会让文章自动出现在 www.56juqingba.com 的首页、分类页、搜索或数据库中。
文中站内链接指向该站现有页面；这些文章本身尚未发布。

全部文章均为编辑草稿，公开前须由合适的真人进行事实与安全审校；
不要虚填作者或专家信息。各篇具体需要核查的内容见该篇的 README-中文.txt。
