How to Listen More Actively｜英文文章素材包

包内包含：
• index.html：英文图文网页（15 个步骤，每步一图，另有一张封面）。
• Images：16 张插画，每张两档 WebP（1600×900 与 960×540），共 32 个图片文件；网页按屏幕宽度自动选用，手机只下载小图。
• Article-English.txt：英文正文、图片文件名、站内外链接和参考资料，适合人工复制。

配图说明：封面与每个步骤均使用不同的插画，均为本文新制。

使用方式：下载后解压；如作为独立网页，请把整个文件夹放在服务器上可被网站访问的静态目录，保持 index.html 和 Images 同级。能否通过网址访问取决于服务器配置；上传压缩包本身不会自动发布。

本包不是已验证的文章系统导入包，不会自动进入原网站首页、分类、搜索或数据库。站内链接指向 www.56juqingba.com 的现有页面；网页尚未发布。英文文章属于「Relationships」类目，公开前须由合适的真人进行事实与安全审校；不要虚填作者或专家信息。
仓库记录的审校说明：Mental health adjacent content. Before publication a qualified counsellor or a trainer from a listening or crisis organisation should review the framing, and the crisis guidance in step 12 and the warnings must be checked against the publishing country's own services, emergency number and safeguarding duties.
